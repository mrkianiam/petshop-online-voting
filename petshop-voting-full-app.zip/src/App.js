
export default function App() {
  return (
    <div style={{
      backgroundColor: '#111',
      color: 'white',
      minHeight: '100vh',
      fontFamily: 'sans-serif',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '24px'
    }}>
      اپلیکیشن رأی‌گیری اسم پت‌شاپ در حال توسعه است...
    </div>
  );
}
