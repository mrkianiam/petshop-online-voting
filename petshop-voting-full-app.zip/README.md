# Petshop Voting App
This is a simple Create React App setup for a voting app.